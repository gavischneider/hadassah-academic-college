package pages.util_pages;

import pages._pages_mngt.MainPageManager;
import pages.super_pages.MenusPage;

public class CategoryContentPage extends MenusPage {

	public CategoryContentPage(MainPageManager pages) {
		super(pages);
	}

}
